﻿
using CreditWebApplication.Models;
using CreditWebApplication.WebServices;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Http.Description;


namespace CreditWebApplication.Controllers
{
    public class HomeController : ApiController
    {


        [HttpGet]
        public HttpResponseMessage factor([FromUri] String mc = "", String comp = "", String phone = "")
        {

            if (comp == "" && mc == "" && phone == "")
            {

                string yourJson = "{\"message\": \"Please provide atleast one of the mc number, company or phone number. in query paramters.\"}";
                var response = this.Request.CreateResponse(HttpStatusCode.BadRequest);
                response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
                return response;
                
            }

            var endpointAddress =
               "http://testws.truckstop.com:8080/V13/CreditStopBroker/CreditStopBroker.svc";

            CompanySearchReturn result;
            WebServices.CreditStopBrokerClient client = new CreditStopBrokerClient(endpointAddress);
            var request = new CompanySearchRequest()
            {
                IntegrationId = 83759,
                UserName = "LinqWS",
                Password = "L1n9trWS",
                CompanyName = "", // this is a ‘search by name’
                McNumber = mc,  // search by McNumber or PhoneNumber is similar – fill in
                PhoneNumber = "" // the one you want & leave the other 2 as an empty-string
            };

             result = client.GetCompanySearchResults(request);


             if (result.SearchResults.Count() > 0)
             {

                 String guid = result.SearchResults[0].CompanyId.ToString();

                 Guid theBrokerGuid = new Guid(guid);
                 var request1 = new RequestByID()
                 {
                     IntegrationId = 83759,
                     UserName = "LinqWS",
                     Password = "L1n9trWS",
                     BrokerID = theBrokerGuid  // the guid returned by the GetCompanySearchResults()
                 };

                 BrokerHistoryReturn bhResult;
                 bhResult = client.GetBrokerCreditHistory(request1);

                 if (bhResult.BrokerHistory.Count() > 0){

                     
                 string yourJson = "{\"experienceFactor\": \"" + bhResult.BrokerHistory[0].ExperienceFactor+"\"}";
                var response = this.Request.CreateResponse(HttpStatusCode.OK);
                response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
                return response;

                 }

                 else
                 {
                     string yourJson = "{\"message\": \"Experience Factor not found    \"}";
                     var response = this.Request.CreateResponse(HttpStatusCode.NotFound);
                     response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
                     return response;
                 }
                     

             }

             else
             {

                 string yourJson = "{\"message\": \"No company found.  \"}";
                 var response = this.Request.CreateResponse(HttpStatusCode.NotFound);
                 response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
                 return response;

                 
             } 

        }


    }
}
